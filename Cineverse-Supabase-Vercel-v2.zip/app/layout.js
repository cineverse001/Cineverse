import "./globals.css";
export const metadata={title:"Cineverse",description:"A legal anime streaming catalog."};
export default function RootLayout({children}){return <html lang="en"><body>{children}</body></html>}
