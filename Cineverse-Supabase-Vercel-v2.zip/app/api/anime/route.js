import { NextResponse } from "next/server";
import { createClient } from "../../../lib/supabase-server";

export async function GET(request){
  const supabase=await createClient();
  const {searchParams}=new URL(request.url);
  const q=searchParams.get("q")||"";
  const genre=searchParams.get("genre");
  let query=supabase.from("anime").select("id,title,slug,synopsis,cover_url,banner_url,year,status,rating,rating_count,anime_genres(genres(name))").order("created_at",{ascending:false});
  if(q) query=query.ilike("title",`%${q}%`);
  const {data,error}=await query;
  if(error) return NextResponse.json({error:error.message},{status:500});
  const filtered=genre?data.filter(a=>a.anime_genres?.some(x=>x.genres?.name===genre)):data;
  return NextResponse.json({data:filtered});
}
