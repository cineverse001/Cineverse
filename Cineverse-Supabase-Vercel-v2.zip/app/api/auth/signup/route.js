import {NextResponse} from "next/server";
import {createClient} from "../../../../lib/supabase-server";
export async function POST(req){
  const supabase=await createClient();
  const {email,password,display_name}=await req.json();
  if(!email||!password||password.length<8) return NextResponse.json({error:"Use an email and a password of at least 8 characters."},{status:400});
  const {data,error}=await supabase.auth.signUp({email,password,options:{data:{display_name}}});
  if(error) return NextResponse.json({error:error.message},{status:400});
  return NextResponse.json({user:data.user,session:data.session});
}
