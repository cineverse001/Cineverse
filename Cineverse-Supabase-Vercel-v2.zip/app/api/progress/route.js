import {NextResponse} from "next/server";
import {createClient} from "../../../lib/supabase-server";

export async function POST(req){
  const supabase=await createClient();
  const {data:{user}}=await supabase.auth.getUser();
  if(!user) return NextResponse.json({error:"Unauthorized"},{status:401});
  const {episode_id,position_seconds,completed}=await req.json();
  const {data,error}=await supabase.from("watch_progress").upsert({
    user_id:user.id,episode_id,position_seconds:Math.max(0,Math.floor(position_seconds||0)),
    completed:!!completed,updated_at:new Date().toISOString()
  }).select().single();
  if(error) return NextResponse.json({error:error.message},{status:400});
  return NextResponse.json({data});
}
