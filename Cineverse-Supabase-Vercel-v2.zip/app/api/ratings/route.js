import {NextResponse} from "next/server";
import {createClient} from "../../../lib/supabase-server";

export async function POST(req){
  const supabase=await createClient();
  const {data:{user}}=await supabase.auth.getUser();
  if(!user) return NextResponse.json({error:"Unauthorized"},{status:401});
  const {anime_id,score}=await req.json();
  if(!anime_id || !Number.isInteger(score) || score<1 || score>5) return NextResponse.json({error:"Invalid rating"},{status:400});
  const {data,error}=await supabase.from("ratings").upsert({user_id:user.id,anime_id,score,updated_at:new Date().toISOString()}).select().single();
  if(error) return NextResponse.json({error:error.message},{status:400});
  return NextResponse.json({data});
}
