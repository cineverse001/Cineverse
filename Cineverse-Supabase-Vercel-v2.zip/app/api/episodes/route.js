import {NextResponse} from "next/server";
import {createClient} from "../../../lib/supabase-server";
export async function GET(req){
 const supabase=await createClient();
 const anime_id=new URL(req.url).searchParams.get("anime_id");
 if(!anime_id)return NextResponse.json({error:"anime_id required"},{status:400});
 const {data,error}=await supabase.from("seasons").select("id,season_number,title,episodes(id,episode_number,title,synopsis,duration_seconds,video_url,vtt_url,is_published)").eq("anime_id",anime_id).order("season_number");
 if(error)return NextResponse.json({error:error.message},{status:500});
 const episodes=(data||[]).flatMap(s=>(s.episodes||[]).filter(e=>e.is_published).map(e=>({...e,season_number:s.season_number}))).sort((a,b)=>a.season_number-b.season_number||a.episode_number-b.episode_number);
 return NextResponse.json({data:episodes});
}
