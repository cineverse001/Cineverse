import {NextResponse} from "next/server";
import {createClient} from "../../../lib/supabase-server";

export async function GET(){
  const supabase=await createClient();
  const {data:{user}}=await supabase.auth.getUser();
  if(!user) return NextResponse.json({error:"Unauthorized"},{status:401});
  const {data,error}=await supabase.from("watchlists").select("anime_id,created_at,anime(*)").eq("user_id",user.id).order("created_at",{ascending:false});
  if(error) return NextResponse.json({error:error.message},{status:500});
  return NextResponse.json({data});
}
export async function POST(req){
  const supabase=await createClient();
  const {data:{user}}=await supabase.auth.getUser();
  if(!user) return NextResponse.json({error:"Unauthorized"},{status:401});
  const body=await req.json();
  const {data,error}=await supabase.from("watchlists").upsert({user_id:user.id,anime_id:body.anime_id}).select().single();
  if(error) return NextResponse.json({error:error.message},{status:400});
  return NextResponse.json({data});
}
export async function DELETE(req){
  const supabase=await createClient();
  const {data:{user}}=await supabase.auth.getUser();
  if(!user) return NextResponse.json({error:"Unauthorized"},{status:401});
  const body=await req.json();
  const {error}=await supabase.from("watchlists").delete().eq("user_id",user.id).eq("anime_id",body.anime_id);
  if(error) return NextResponse.json({error:error.message},{status:400});
  return NextResponse.json({ok:true});
}
