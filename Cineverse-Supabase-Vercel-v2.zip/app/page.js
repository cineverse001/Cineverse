import Cineverse from "../components/Cineverse";
export default function Page(){return <Cineverse/>}
