create extension if not exists "pgcrypto";

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  avatar_url text,
  is_admin boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.anime (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  slug text unique not null,
  synopsis text,
  cover_url text,
  banner_url text,
  year integer,
  status text not null default 'Ongoing' check (status in ('Ongoing','Complete','Upcoming')),
  rating numeric(3,1) not null default 0,
  rating_count integer not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.genres (
  id uuid primary key default gen_random_uuid(),
  name text unique not null
);

create table if not exists public.anime_genres (
  anime_id uuid not null references public.anime(id) on delete cascade,
  genre_id uuid not null references public.genres(id) on delete cascade,
  primary key (anime_id, genre_id)
);

create table if not exists public.seasons (
  id uuid primary key default gen_random_uuid(),
  anime_id uuid not null references public.anime(id) on delete cascade,
  season_number integer not null,
  title text,
  unique(anime_id, season_number)
);

create table if not exists public.episodes (
  id uuid primary key default gen_random_uuid(),
  season_id uuid not null references public.seasons(id) on delete cascade,
  episode_number integer not null,
  title text,
  synopsis text,
  duration_seconds integer,
  video_url text,
  vtt_url text,
  is_published boolean not null default false,
  created_at timestamptz not null default now(),
  unique(season_id, episode_number)
);

create table if not exists public.watchlists (
  user_id uuid not null references auth.users(id) on delete cascade,
  anime_id uuid not null references public.anime(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(user_id, anime_id)
);

create table if not exists public.ratings (
  user_id uuid not null references auth.users(id) on delete cascade,
  anime_id uuid not null references public.anime(id) on delete cascade,
  score integer not null check(score between 1 and 5),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  primary key(user_id, anime_id)
);

create table if not exists public.watch_progress (
  user_id uuid not null references auth.users(id) on delete cascade,
  episode_id uuid not null references public.episodes(id) on delete cascade,
  position_seconds integer not null default 0 check(position_seconds >= 0),
  completed boolean not null default false,
  updated_at timestamptz not null default now(),
  primary key(user_id, episode_id)
);

create index if not exists anime_title_idx on public.anime using gin (to_tsvector('english', title));
create index if not exists episodes_season_idx on public.episodes(season_id);
create index if not exists watch_progress_user_idx on public.watch_progress(user_id);

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles(id, display_name)
  values(new.id, coalesce(new.raw_user_meta_data->>'display_name', split_part(new.email,'@',1)))
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

create or replace function public.recalculate_anime_rating()
returns trigger
language plpgsql
security definer set search_path = public
as $$
declare target_anime uuid;
begin
  target_anime := coalesce(new.anime_id, old.anime_id);
  update public.anime a
  set rating = coalesce((select round(avg(r.score)::numeric,1) from public.ratings r where r.anime_id=target_anime),0),
      rating_count = (select count(*) from public.ratings r where r.anime_id=target_anime)
  where a.id=target_anime;
  return coalesce(new,old);
end;
$$;

drop trigger if exists ratings_recalculate on public.ratings;
create trigger ratings_recalculate
after insert or update or delete on public.ratings
for each row execute procedure public.recalculate_anime_rating();

alter table public.profiles enable row level security;
alter table public.anime enable row level security;
alter table public.genres enable row level security;
alter table public.anime_genres enable row level security;
alter table public.seasons enable row level security;
alter table public.episodes enable row level security;
alter table public.watchlists enable row level security;
alter table public.ratings enable row level security;
alter table public.watch_progress enable row level security;

drop policy if exists "published catalog is public" on public.anime;
create policy "published catalog is public" on public.anime for select using (true);
drop policy if exists "genres are public" on public.genres;
create policy "genres are public" on public.genres for select using (true);
drop policy if exists "anime genres are public" on public.anime_genres;
create policy "anime genres are public" on public.anime_genres for select using (true);
drop policy if exists "seasons are public" on public.seasons;
create policy "seasons are public" on public.seasons for select using (true);
drop policy if exists "published episodes are public" on public.episodes;
create policy "published episodes are public" on public.episodes for select using (is_published = true);

drop policy if exists "own profile" on public.profiles;
create policy "own profile" on public.profiles for select using (auth.uid()=id);
create policy "update own profile" on public.profiles for update using (auth.uid()=id);

drop policy if exists "own watchlist" on public.watchlists;
create policy "own watchlist" on public.watchlists for all using (auth.uid()=user_id) with check (auth.uid()=user_id);

drop policy if exists "ratings readable" on public.ratings;
create policy "ratings readable" on public.ratings for select using (true);
create policy "own ratings write" on public.ratings for insert with check (auth.uid()=user_id);
create policy "own ratings update" on public.ratings for update using (auth.uid()=user_id) with check (auth.uid()=user_id);
create policy "own ratings delete" on public.ratings for delete using (auth.uid()=user_id);

drop policy if exists "own progress" on public.watch_progress;
create policy "own progress" on public.watch_progress for all using (auth.uid()=user_id) with check (auth.uid()=user_id);

insert into public.genres(name) values
('Action'),('Adventure'),('Comedy'),('Drama'),('Fantasy'),('Romance'),('Sci-Fi')
on conflict (name) do nothing;

insert into public.anime(title,slug,synopsis,year,status,rating,rating_count)
values
('Moonlit Samurai','moonlit-samurai','A wandering swordsman follows a mysterious moonlit trail across a world of ancient cities.',2026,'Ongoing',8.8,0),
('Neon Skies','neon-skies','Young pilots navigate a glowing megacity while uncovering a forgotten signal.',2025,'Complete',9.1,0),
('Paper Hearts','paper-hearts','Two artists discover that every sketch they share brings their worlds closer.',2026,'Ongoing',8.4,0),
('Spirit Garden','spirit-garden','A student enters a hidden garden where spirits guard memories of the past.',2024,'Complete',8.7,0),
('Pixel Raiders','pixel-raiders','A team of arcade champions gets pulled into the worlds of their favorite games.',2025,'Ongoing',8.2,0),
('Blue Horizon','blue-horizon','A quiet seaside town becomes the backdrop for an unforgettable summer.',2023,'Complete',8.9,0)
on conflict (slug) do nothing;

insert into public.anime_genres(anime_id,genre_id)
select a.id,g.id from public.anime a cross join public.genres g
where (a.slug='moonlit-samurai' and g.name='Action')
or (a.slug='neon-skies' and g.name='Sci-Fi')
or (a.slug='paper-hearts' and g.name='Romance')
or (a.slug='spirit-garden' and g.name='Fantasy')
or (a.slug='pixel-raiders' and g.name='Adventure')
or (a.slug='blue-horizon' and g.name='Drama')
on conflict do nothing;

insert into public.seasons(anime_id,season_number,title)
select id,1,'Season 1' from public.anime
on conflict (anime_id,season_number) do nothing;

insert into public.episodes(season_id,episode_number,title,is_published)
select s.id, gs, 'Episode '||gs, false
from public.seasons s cross join generate_series(1,12) gs
on conflict do nothing;
