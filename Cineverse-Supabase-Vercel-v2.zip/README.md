# Cineverse 2.0 — Supabase + Vercel

Production-oriented Next.js starter for a legal anime streaming catalog.

## 1. Supabase

Create a Supabase project, then open **SQL Editor** and run:

`supabase/schema.sql`

This creates the catalog, seasons, episodes, genres, ratings, watchlists, watch progress, RLS policies, and seed catalog.

Then copy your Supabase project URL and anon key into `.env.local` using `.env.example`.

## 2. Run locally

Node.js 18+ is recommended.

```bash
npm install
npm run dev
```

Open http://localhost:3000.

## 3. Authentication

The app uses Supabase email/password authentication.

Sign up/sign in is handled by `/api/auth/signup` and `/api/auth/signin`.
Email confirmation behavior depends on your Supabase Auth settings.

## 4. Deploy to Vercel

Push this project to GitHub, import it into Vercel, and add:

- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`

Deploy.

## 5. Licensed media

Episodes contain an optional `video_url` and subtitle `vtt_url`. Add only media you are authorized to stream. The player supports a WebVTT subtitle track.

For production, consider putting video behind a licensed CDN or signed URLs instead of exposing permanent public media URLs.

## 6. Admin

The schema includes an `is_admin` flag in profiles. The included catalog API is intentionally read-focused. Add a protected admin dashboard/server actions before allowing catalog writes in production.

## 7. Important production checklist

- Configure a custom Supabase email SMTP provider.
- Configure your production Site URL and redirect URLs in Supabase Auth.
- Add a real privacy policy and terms.
- Add moderation/content-rights workflows.
- Use signed media URLs where appropriate.
- Add rate limiting to auth and write endpoints.
- Add monitoring/error tracking.
